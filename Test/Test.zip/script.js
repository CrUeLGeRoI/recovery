// while(true){
//     let num = prompt("Введи число больше 100!")
//     if (num < 100 && num != null){
//         alert("БОЛЬШЕ 100!!!")
//     }
//     else if(isNaN(num)){
//         alert("Не буквы, а строку!!!")
//     }
//     else if (num == null){
//         break
//     }
//     else{
//         break
//     }
// }
var button = document.createElement('button')
button.textContent = 'Random color'
document.body.appendChild(button)
    var colors = ['blue', 'pink', 'yellow', 'red', '#000', '#fff']
    button.onclick = function() {
       document.body.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)]
    }